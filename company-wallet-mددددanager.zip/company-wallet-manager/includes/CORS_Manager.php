<?php

namespace CWM;

/**
 * Manage REST API CORS headers so the React panel can call WordPress endpoints from approved origins.
 */
class CORS_Manager {
        /**
         * Bootstrap hooks.
         */
        public function __construct() {
                add_action( 'init', [ $this, 'maybe_handle_preflight' ] );
                add_action( 'rest_api_init', [ $this, 'register_cors_headers' ], 15 );
        }

        /**
         * Ensure OPTIONS preflight requests receive the same headers as regular REST responses.
         */
        public function maybe_handle_preflight() {
                if ( ! isset( $_SERVER['REQUEST_METHOD'] ) || 'OPTIONS' !== $_SERVER['REQUEST_METHOD'] ) {
                        return;
                }

                if ( empty( $_SERVER['REQUEST_URI'] ) ) {
                        return;
                }

                $rest_prefix = '/' . ltrim( rest_get_url_prefix(), '/' );
                $request_uri = sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) );
                
                // Check if this is a REST API request
                if ( 0 !== strpos( $request_uri, $rest_prefix ) ) {
                        return;
                }

                $origin = get_http_origin();
                if ( ! $origin ) {
                        // If no origin header, it might be same-origin or direct request
                        // Don't send CORS headers for same-origin requests
                        status_header( 200 );
                        exit;
                }

                // Normalize and check if origin is allowed
                $normalized_origin = $this->normalize_origin( $origin );
                if ( ! $normalized_origin ) {
                        status_header( 403 );
                        exit;
                }

                // Check if origin is allowed (including subdomain matching)
                if ( $this->is_origin_allowed( $normalized_origin ) ) {
                        $this->send_cors_headers( $origin );
                        status_header( 200 );
                        exit;
                }

                // If not explicitly allowed, check if it's from same domain (subdomain support)
                $origin_domain = $this->get_registered_domain_from_origin( $origin );
                $site_domain = $this->get_registered_domain_from_origin( home_url() );
                
                if ( $origin_domain && $site_domain && $origin_domain === $site_domain ) {
                        // Allow subdomains of the same domain (e.g., panel.vandapay.com from mr.vandapay.com)
                        $this->send_cors_headers( $origin );
                        status_header( 200 );
                        exit;
                }

                // Origin not allowed
                status_header( 403 );
                exit;

                // End execution early so WordPress does not try to render a page.
                status_header( 200 );
                exit;
        }

        /**
         * Attach CORS headers to REST responses for allowed origins.
         */
        public function register_cors_headers() {
                remove_filter( 'rest_pre_serve_request', 'rest_send_cors_headers' );

                add_filter(
                        'rest_pre_serve_request',
                        function ( $value, $result, $request, $server ) {
                                $origin = get_http_origin();
                                
                                // If no origin, it might be same-origin request
                                if ( ! $origin ) {
                                        return $value;
                                }

                                $normalized_origin = $this->normalize_origin( $origin );
                                if ( $normalized_origin && $this->is_origin_allowed( $normalized_origin ) ) {
                                        $this->send_cors_headers( $origin );
                                } elseif ( $this->is_same_domain_origin( $origin ) ) {
                                        // Allow same domain (for subdomains like panel.vandapay.com -> mr.vandapay.com)
                                        $this->send_cors_headers( $origin );
                                }

                                return $value;
                        },
                        15,
                        4
                );
        }

        /**
         * Check if origin is from same domain (for subdomain support).
         *
         * @param string $origin
         * @return bool
         */
        private function is_same_domain_origin( $origin ) {
                $origin_domain = $this->get_registered_domain_from_origin( $origin );
                $site_domain = $this->get_registered_domain_from_origin( home_url() );
                return $origin_domain && $site_domain && $origin_domain === $site_domain;
        }

        /**
         * Determine whether the given origin has been whitelisted.
         *
         * @param string $origin The HTTP origin making the request.
         * @return bool
         */
        private function is_origin_allowed( $origin ) {
                $origin = $this->normalize_origin( $origin );
                if ( ! $origin ) {
                        return false;
                }

                $allowed_origins = $this->get_allowed_origins();

                // Exact match
                if ( in_array( $origin, $allowed_origins, true ) ) {
                        return true;
                }

                // Check domain matching for subdomains
                $origin_domain = $this->get_registered_domain_from_origin( $origin );
                if ( ! $origin_domain ) {
                        return false;
                }

                $site_domains = array_filter(
                        array(
                                $this->get_registered_domain_from_origin( home_url() ),
                                $this->get_registered_domain_from_origin( site_url() ),
                        )
                );

                // Check if origin is from same domain (subdomain support)
                foreach ( $site_domains as $domain ) {
                        if ( $domain && $domain === $origin_domain ) {
                                return true;
                        }
                }

                // Check against allowed origins
                foreach ( $allowed_origins as $allowed_origin ) {
                        $allowed_domain = $this->get_registered_domain_from_origin( $allowed_origin );
                        if ( $allowed_domain && $origin_domain === $allowed_domain ) {
                                return true;
                        }
                }

                return false;
        }

        /**
         * Retrieve the list of allowed origins.
         *
         * @return array
         */
        private function get_allowed_origins() {
                $defaults = array(
                        $this->normalize_origin( home_url() ),
                        $this->normalize_origin( site_url() ),
                );

                $configured = array();

                if ( defined( 'CWM_ALLOWED_CORS_ORIGINS' ) ) {
                        $raw = CWM_ALLOWED_CORS_ORIGINS;
                        if ( is_string( $raw ) ) {
                                $configured = array_merge( $configured, array_map( 'trim', explode( ',', $raw ) ) );
                        } elseif ( is_array( $raw ) ) {
                                $configured = array_merge( $configured, $raw );
                        }
                }

                $settings = get_option( 'cwm_settings', [] );
                if ( ! empty( $settings['allowed_origins'] ) ) {
                        $configured = array_merge( $configured, array_map( 'trim', explode( ',', $settings['allowed_origins'] ) ) );
                }

                $configured = array_map( [ $this, 'normalize_origin' ], $configured );
                $origins    = array_filter( array_merge( $defaults, $configured ) );
                $origins    = array_unique( $origins );

                /**
                 * Filter the list of CORS origins that may access the REST API.
                 *
                 * @since 1.0.3
                 *
                 * @param array $origins The allowed origins.
                 */
                return apply_filters( 'cwm_allowed_cors_origins', $origins );
        }

        /**
         * Normalize a potential origin string.
         *
         * @param string $origin Possible origin value.
         * @return string|null
         */
        private function normalize_origin( $origin ) {
                if ( ! $origin || ! is_string( $origin ) ) {
                        return null;
                }

                $parsed = wp_parse_url( trim( $origin ) );
                if ( empty( $parsed['scheme'] ) || empty( $parsed['host'] ) ) {
                        return null;
                }

                $port = isset( $parsed['port'] ) ? ':' . $parsed['port'] : '';

                return strtolower( $parsed['scheme'] . '://' . $parsed['host'] . $port );
        }

        /**
         * Output the headers shared by both preflight and regular REST responses.
         *
         * @param string $origin Origin to echo in the header values.
         */
        private function send_cors_headers( $origin ) {
                header( 'Access-Control-Allow-Origin: ' . esc_url_raw( $origin ) );
                header( 'Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS' );
                header( 'Access-Control-Allow-Credentials: true' );
                header( 'Access-Control-Allow-Headers: Authorization, Content-Type, X-WP-Nonce, X-Requested-With' );
                header( 'Access-Control-Max-Age: 86400' );
                header( 'Vary: Origin' );
        }

        /**
         * Build the registrable domain for an origin so sibling subdomains can be matched.
         *
         * @param string $origin Origin string.
         * @return string|null
         */
        private function get_registered_domain_from_origin( $origin ) {
                if ( ! $origin ) {
                        return null;
                }

                $host = wp_parse_url( $origin, PHP_URL_HOST );
                if ( ! $host ) {
                        return null;
                }

                $parts = array_values( array_filter( explode( '.', strtolower( $host ) ) ) );
                $count = count( $parts );

                if ( 0 === $count ) {
                        return null;
                }

                if ( 1 === $count ) {
                        return $parts[0];
                }

                $tld           = array_pop( $parts );
                $second_level  = array_pop( $parts );
                $known_sl_tlds = array( 'co', 'com', 'net', 'org', 'gov', 'edu', 'ac' );

                if ( in_array( $second_level, $known_sl_tlds, true ) && ! empty( $parts ) ) {
                        $second_level = array_pop( $parts ) . '.' . $second_level;
                }

                return $second_level . '.' . $tld;
        }
}
